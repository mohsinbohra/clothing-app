import React from 'react';
import './sign-in-and-sign-up.styles.scss'
import SingIn from '../../components/sign-in/sign-in.component';

const SignInAndSignUp = () => (

    <div className="sign-in-and-sing-up">
    <SingIn />
    </div>
)

export default SignInAndSignUp;